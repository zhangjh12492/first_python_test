from distutils.core import setup

setup(
    name='nester',
    version='1.1.1',
    py_modules=['nester'],
    author='joey',
    author_email='joey12492@gmail.com',
    url='http://www.joey.com',
    description='A simple printer of nested list'
)

